touch --no-create /usr/share/icons/hicolor &>/dev/null || :

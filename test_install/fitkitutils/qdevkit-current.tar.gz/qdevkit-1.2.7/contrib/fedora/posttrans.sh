gtk-update-icon-cache /usr/share/icons/hicolor &>/dev/null || :

#ifndef QDK_PLUGIN_EXPORT_H
#include <QtCore/QtGlobal>
#if defined(QDKPLUGIN_DO_EXPORT)
#  define QDKPLUGIN_EXPORT Q_DECL_EXPORT
#else
#  define QDKPLUGIN_EXPORT Q_DECL_IMPORT
#endif
#endif


<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="cs">
<context>
    <name>AboutDialog</name>
    <message>
        <location filename="../ui/aboutdialog.ui" line="35"/>
        <source>About</source>
        <translation>O Aplikaci</translation>
    </message>
    <message>
        <location filename="../ui/aboutdialog.ui" line="62"/>
        <source>Close</source>
        <translation>Uzavřít</translation>
    </message>
    <message>
        <location filename="../ui/aboutdialog.ui" line="106"/>
        <source>&amp;About</source>
        <translation>&amp;O Aplikaci</translation>
    </message>
    <message>
        <location filename="../ui/aboutdialog.ui" line="145"/>
        <source>Au&amp;thors</source>
        <translation>Au&amp;toři</translation>
    </message>
    <message>
        <location filename="../ui/aboutdialog.ui" line="217"/>
        <source>Thank&amp;s to</source>
        <translation>Podě&amp;kování</translation>
    </message>
    <message>
        <location filename="../ui/aboutdialog.ui" line="304"/>
        <source>QDevKit</source>
        <translation>QDevKit</translation>
    </message>
    <message utf8="true">
        <location filename="../ui/aboutdialog.ui" line="241"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Bitstream Vera Sans&apos;; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Jan Vavruša&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;    &lt;a href=&quot;mailto:jan@vavrusa.com&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0057ae;&quot;&gt;jan@vavrusa.com&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;    Application graphics&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Oxygen team&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;    &lt;a href=&quot;http://www.oxygen-icons.org/&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0057ae;&quot;&gt;www.oxygen-icons.org&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;    Application iconset&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../ui/aboutdialog.ui" line="112"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Bitstream Vera Sans&apos;; font-size:9pt; font-weight:600;&quot;&gt;FITKit development toolkit&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;Bitstream Vera Sans&apos;; font-size:9pt;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Bitstream Vera Sans&apos;; font-size:9pt;&quot;&gt;Licensed under GNU/GPL v2.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;Bitstream Vera Sans&apos;; font-size:9pt;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Bitstream Vera Sans&apos;; font-size:9pt;&quot;&gt;(C) 2008/2013 Marek Vavruša, Zdeněk Vašíček&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;Bitstream Vera Sans&apos;; font-size:9pt;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a href=&quot;http://www.fit.vutbr.cz/fitkit&quot;&gt;&lt;span style=&quot; font-family:&apos;Bitstream Vera Sans&apos;; font-size:9pt; text-decoration: underline; color:#0057ae;&quot;&gt;http://www.fit.vutbr.cz/kit&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../ui/aboutdialog.ui" line="175"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Bitstream Vera Sans&apos;;&quot;&gt;Please use &lt;/span&gt;&lt;a href=&quot;http://merlin.fit.vutbr.cz/FITkit/forum.html&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;FITkit forum&lt;/span&gt;&lt;/a&gt;&lt;span style=&quot; font-family:&apos;Bitstream Vera Sans&apos;;&quot;&gt; to report bugs.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;Bitstream Vera Sans&apos;;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Bitstream Vera Sans&apos;;&quot;&gt;Marek Vavruša&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Bitstream Vera Sans&apos;;&quot;&gt;   &lt;/span&gt;&lt;a href=&quot;mailto:marek@vavrusa.com&quot;&gt;&lt;span style=&quot; font-family:&apos;Bitstream Vera Sans&apos;; text-decoration: underline; color:#0057ae;&quot;&gt;marek@vavrusa.com&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Bitstream Vera Sans&apos;;&quot;&gt;   Maintainer and developer&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;Bitstream Vera Sans&apos;;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Bitstream Vera Sans&apos;;&quot;&gt;Zdeněk Vašíček&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Bitstream Vera Sans&apos;;&quot;&gt;   &lt;/span&gt;&lt;a href=&quot;mailto:vasicek@fit.vutbr.cz&quot;&gt;&lt;span style=&quot; font-family:&apos;Bitstream Vera Sans&apos;; text-decoration: underline; color:#0057ae;&quot;&gt;vasicek@fit.vutbr.cz&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Bitstream Vera Sans&apos;;&quot;&gt;   Maintainer and developer&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/aboutdialog.ui" line="323"/>
        <source>Version X.X.X</source>
        <translation>Verze X.X.X</translation>
    </message>
</context>
<context>
    <name>CloseDialog</name>
    <message>
        <location filename="../ui/closedialog.ui" line="16"/>
        <source>Quit?</source>
        <translation>Ukončit aplikaci?</translation>
    </message>
    <message>
        <location filename="../ui/closedialog.ui" line="67"/>
        <source>Do not ask again</source>
        <translation>Znovu se nedotazovat</translation>
    </message>
    <message>
        <location filename="../ui/closedialog.ui" line="80"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Bitstream Vera Sans&apos;; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Do you really want to quit?&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-weight:600;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-weight:600;&quot;&gt;&lt;span style=&quot; font-weight:400;&quot;&gt;Exiting can result in losing sessions, that you didn&apos;t save.&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;p, li { white-space: pre-wrap; }&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Bitstream Vera Sans&apos;; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Opravdu chcete ukončit aplikaci?&lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-weight:600;&quot;&gt;&lt;/p&gt;&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-weight:600;&quot;&gt;&lt;span style=&quot; font-weight:400;&quot;&gt;Okamžité ukončení může mít za následek ztrátu neuložených dat.&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
</context>
<context>
    <name>Connection</name>
    <message>
        <location filename="../ui/connection.cpp" line="118"/>
        <source>Cannot open device channel</source>
        <translation>Nepodařilo se otevřít kanál pro komunikaci</translation>
    </message>
    <message>
        <source>&lt;p&gt;Opening device channel &quot;&lt;b&gt;%0&lt;/b&gt;&quot; failed with error code &quot;%1&quot;.&lt;/p&gt;&lt;p&gt;Please check your permissions and&lt;br/&gt;add yourself to the group &lt;b&gt;plugdev&lt;/b&gt;.&lt;/p&gt;&lt;p&gt;&lt;i&gt;Associated devices should be &lt;b&gt;/dev/ttyUSB*&lt;/b&gt;.&lt;/i&gt;&lt;/p&gt;</source>
        <translation type="obsolete">&lt;p&gt;Nepodařilo se otevřít kanál &quot;&lt;b&gt;%0&lt;/b&gt;&quot;. Chybový kód: &quot;%1&quot;.&lt;/p&gt;&lt;p&gt;Prosím zkontrolujte nastavení práv pro dané zařízení a &lt;br/&gt;ověřte, zda-li jste ve skupině &lt;b&gt;plugdev&lt;/b&gt;.&lt;/p&gt;&lt;p&gt;&lt;i&gt;Asociovaná zařízení jsou obvykle &lt;b&gt;/dev/ttyUSB*&lt;/b&gt;.&lt;/i&gt;&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../ui/connection.cpp" line="119"/>
        <source>&lt;p&gt;Opening device channel &quot;&lt;b&gt;%0&lt;/b&gt;&quot; failed with error code &quot;%1&quot;.&lt;/p&gt;&lt;p&gt;Please check your permissions and&lt;br/&gt;add yourself to the group &lt;b&gt;dialout&lt;/b&gt; or similar..&lt;/p&gt;&lt;p&gt;&lt;i&gt;You should have write permissions to devices&lt;b&gt;/dev/ttyUSB*&lt;/b&gt;.&lt;/i&gt;&lt;/p&gt;</source>
        <translation>&lt;p&gt;Nepodařilo se otevřít kanál &quot;&lt;b&gt;%0&lt;/b&gt;&quot;. Chybový kód: &quot;%1&quot;.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../ui/connection.cpp" line="261"/>
        <source>&amp;Send</source>
        <translation>Ode&amp;slat</translation>
    </message>
    <message>
        <location filename="../ui/connection.cpp" line="481"/>
        <source>Serial connection to FITkit was lost</source>
        <translation>Sériové spojení s FITkitem bylo ztraceno</translation>
    </message>
    <message>
        <location filename="../ui/connection.cpp" line="482"/>
        <source>Device was probably disconnected from the computer.
Please check the cabling and the device and try again.</source>
        <translation>Zařízení bylo pravděpodobně odpojeno od počítače.
Zkontrolujte FITkit a kabely, a pokuste se znovu připojit.</translation>
    </message>
</context>
<context>
    <name>ConnectionTabs</name>
    <message>
        <location filename="../ui/connectiontabs.cpp" line="207"/>
        <source>FITkit</source>
        <translation>FITkit</translation>
    </message>
    <message>
        <location filename="../ui/connectiontabs.cpp" line="250"/>
        <source>FITkit (Channels: </source>
        <translation>FITkit (Kanál:</translation>
    </message>
    <message>
        <location filename="../ui/connectiontabs.cpp" line="266"/>
        <source>Channel A</source>
        <translation>Kanál A</translation>
    </message>
    <message>
        <location filename="../ui/connectiontabs.cpp" line="267"/>
        <source>Channel B</source>
        <translation>Kanál B</translation>
    </message>
    <message>
        <location filename="../ui/connectiontabs.cpp" line="265"/>
        <source>Reset MCU</source>
        <translation>Reset MCU</translation>
    </message>
    <message>
        <source>Both channels</source>
        <translation type="obsolete">Oba kanály</translation>
    </message>
    <message>
        <location filename="../ui/connectiontabs.cpp" line="385"/>
        <source>Connection is busy.</source>
        <translation>Spojení je zaneprázdněné.</translation>
    </message>
    <message>
        <location filename="../ui/connectiontabs.cpp" line="386"/>
        <source>&lt;p&gt;Closing the device by force may result in unexpected behaviour if it&apos;s under operation.&lt;/p&gt;&lt;p&gt;Do you really want to close the connection?&lt;/p&gt;</source>
        <translation>&lt;p&gt;Se zařízením se pracuje. Násilné uzavření zařízení může mít za následek neočekávané chování zařízení.&lt;/p&gt;&lt;p&gt;Opravdu chcete uzavřít spojení?&lt;/p&gt;</translation>
    </message>
    <message>
        <source>FITKit (Channel %1)</source>
        <translation type="obsolete">FITKit (Kanál %1)</translation>
    </message>
</context>
<context>
    <name>DeviceConfig</name>
    <message>
        <location filename="../ui/deviceconfig.cpp" line="83"/>
        <source>Connection</source>
        <translation>Připojení</translation>
    </message>
    <message>
        <location filename="../ui/deviceconfig.cpp" line="85"/>
        <source>Identification</source>
        <translation>Identifikace</translation>
    </message>
    <message>
        <location filename="../ui/deviceconfig.cpp" line="127"/>
        <source>Vendor IDs:</source>
        <translation>Seznam &quot;Vendor ID&quot;:</translation>
    </message>
    <message>
        <location filename="../ui/deviceconfig.cpp" line="128"/>
        <source>Product IDs:</source>
        <translation>Seznam &quot;Product ID&quot;:</translation>
    </message>
    <message>
        <location filename="../ui/deviceconfig.cpp" line="84"/>
        <source>Capabilities</source>
        <translation>Možnosti</translation>
    </message>
    <message>
        <location filename="../ui/deviceconfig.cpp" line="99"/>
        <source>Flashing:</source>
        <translation>Programování</translation>
    </message>
</context>
<context>
    <name>DeviceCustomDialog</name>
    <message>
        <location filename="../ui/devicecustomdialog.cpp" line="45"/>
        <source>Open custom device</source>
        <translation>Otevřít zařízení s parametry</translation>
    </message>
    <message>
        <location filename="../ui/devicecustomdialog.cpp" line="59"/>
        <source>Properties</source>
        <translation>Vlastnosti</translation>
    </message>
</context>
<context>
    <name>DeviceDialog</name>
    <message>
        <location filename="../ui/devicedialog.cpp" line="84"/>
        <source>Device</source>
        <translation>Zařízení</translation>
    </message>
    <message>
        <location filename="../ui/devicedialog.cpp" line="48"/>
        <source>Connect</source>
        <translation>Připojit</translation>
    </message>
    <message>
        <location filename="../ui/devicedialog.cpp" line="95"/>
        <source>C&amp;onnect</source>
        <translation>&amp;Připojit</translation>
    </message>
    <message>
        <location filename="../ui/devicedialog.cpp" line="96"/>
        <source>&amp;Cancel</source>
        <translation>&amp;Zrušit</translation>
    </message>
</context>
<context>
    <name>DeviceProperties</name>
    <message>
        <location filename="../ui/deviceconfig.cpp" line="146"/>
        <location filename="../ui/deviceconfig.cpp" line="160"/>
        <source>Channel B</source>
        <translation>Kanál B</translation>
    </message>
    <message>
        <location filename="../ui/deviceconfig.cpp" line="147"/>
        <location filename="../ui/deviceconfig.cpp" line="175"/>
        <source>None</source>
        <translation>None</translation>
    </message>
    <message>
        <location filename="../ui/deviceconfig.cpp" line="160"/>
        <source>Channel A</source>
        <translation>Kanál A</translation>
    </message>
    <message>
        <location filename="../ui/deviceconfig.cpp" line="175"/>
        <source>Even</source>
        <translation>Even</translation>
    </message>
    <message>
        <location filename="../ui/deviceconfig.cpp" line="175"/>
        <source>Odd</source>
        <translation>Odd</translation>
    </message>
    <message>
        <location filename="../ui/deviceconfig.cpp" line="175"/>
        <source>Mark</source>
        <translation>Mark</translation>
    </message>
    <message>
        <location filename="../ui/deviceconfig.cpp" line="175"/>
        <source>Space</source>
        <translation>Space</translation>
    </message>
    <message>
        <location filename="../ui/deviceconfig.cpp" line="181"/>
        <source>Baud rate:</source>
        <translation>Rychlost:</translation>
    </message>
    <message>
        <location filename="../ui/deviceconfig.cpp" line="182"/>
        <source>Device channel:</source>
        <translation>Výchozí kanál:</translation>
    </message>
    <message>
        <location filename="../ui/deviceconfig.cpp" line="183"/>
        <source>Bits type:</source>
        <translation>Bity:</translation>
    </message>
    <message>
        <location filename="../ui/deviceconfig.cpp" line="184"/>
        <source>Stop-bits type:</source>
        <translation>Stop-bity:</translation>
    </message>
    <message>
        <location filename="../ui/deviceconfig.cpp" line="185"/>
        <source>Parity:</source>
        <translation>Parita:</translation>
    </message>
</context>
<context>
    <name>DeviceTree</name>
    <message>
        <source>Devices at local bus</source>
        <translation type="obsolete">Připojená zařízení</translation>
    </message>
    <message>
        <location filename="../ui/devicetree.cpp" line="78"/>
        <source>Available devices</source>
        <translation>Dostupná zařízení</translation>
    </message>
    <message>
        <location filename="../ui/devicetree.cpp" line="91"/>
        <source>Local USB bus</source>
        <translation>Lokální USB</translation>
    </message>
    <message>
        <location filename="../ui/devicetree.cpp" line="98"/>
        <source>Local network</source>
        <translation>Místní síť</translation>
    </message>
    <message>
        <location filename="../ui/devicetree.cpp" line="105"/>
        <source>Remote devices</source>
        <translation>Vzdálená zařízení</translation>
    </message>
    <message>
        <location filename="../ui/devicetree.cpp" line="133"/>
        <source>&amp;Disconnect</source>
        <translation>O&amp;dpojit</translation>
    </message>
    <message>
        <location filename="../ui/devicetree.cpp" line="161"/>
        <source>Un&amp;share device</source>
        <translation>Zrušit &amp;sdílení</translation>
    </message>
    <message>
        <location filename="../ui/devicetree.cpp" line="164"/>
        <source>&amp;Share device</source>
        <translation>&amp;Sdílet zařízení</translation>
    </message>
    <message>
        <location filename="../ui/devicetree.cpp" line="403"/>
        <source>FITkit #%1
%4:%5
VID 0x%2, PID 0x%3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/devicetree.cpp" line="410"/>
        <source>FITkit #%1
VID 0x%2, PID 0x%3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/devicetree.cpp" line="419"/>
        <source>
SN: %1</source>
        <translation>SN: %1</translation>
    </message>
</context>
<context>
    <name>FkAppWidget</name>
    <message>
        <location filename="../ui/fktreeconfig.cpp" line="658"/>
        <source>&amp;Refresh</source>
        <translation>&amp;Obnovit</translation>
    </message>
    <message>
        <location filename="../ui/fktreeconfig.cpp" line="662"/>
        <source>Re&amp;build</source>
        <translation>&amp;Přeložit</translation>
    </message>
    <message>
        <location filename="../ui/fktreeconfig.cpp" line="666"/>
        <source>&amp;Clean</source>
        <translation>&amp;Vyčistit</translation>
    </message>
    <message>
        <location filename="../ui/fktreeconfig.cpp" line="705"/>
        <source>&lt;b&gt;%1&lt;/b&gt;&lt;br&gt;%2&lt;br&gt;&lt;small&gt;&lt;span&gt;%3, &lt;a href=&apos;mailto:%4&apos;&gt;%4&lt;/a&gt;&lt;/span&gt;&lt;br&gt;Revision: &lt;b&gt;%5&lt;/b&gt; %6&lt;/small&gt;</source>
        <translation>&lt;b&gt;%1&lt;/b&gt;&lt;br&gt;%2&lt;br&gt;&lt;small&gt;&lt;span&gt;%3, &lt;a href=&apos;mailto:%4&apos;&gt;%4&lt;/a&gt;&lt;/span&gt;&lt;br&gt;Revize: &lt;b&gt;%5&lt;/b&gt; %6&lt;/small&gt;</translation>
    </message>
    <message>
        <location filename="../ui/fktreeconfig.cpp" line="697"/>
        <source>&lt;b&gt;&lt;font color=&apos;orange&apos;&gt; (build outdated) &lt;/font&gt;&lt;/b&gt;</source>
        <translation>&lt;b&gt;&lt;font color=&apos;orange&apos;&gt; (zastaralá verze) &lt;/font&gt;&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../ui/fktreeconfig.cpp" line="703"/>
        <source>&lt;b&gt;&lt;font color=&apos;red&apos;&gt; (not compiled) &lt;/font&gt;&lt;/b&gt;</source>
        <translation>&lt;b&gt;&lt;font color=&apos;red&apos;&gt; (není přeloženo) &lt;/font&gt;&lt;/b&gt;</translation>
    </message>
</context>
<context>
    <name>FkTreeConfig</name>
    <message>
        <location filename="../ui/fktreeconfig.cpp" line="198"/>
        <source>Add local application</source>
        <translation>Přidat aplikaci</translation>
    </message>
    <message>
        <location filename="../ui/fktreeconfig.cpp" line="199"/>
        <source>Download application</source>
        <translation>Stáhnout aplikaci</translation>
    </message>
    <message>
        <location filename="../ui/fktreeconfig.cpp" line="393"/>
        <source>Subversion not found!</source>
        <translation>Aplikace Subversion nenalezena!</translation>
    </message>
    <message>
        <location filename="../ui/fktreeconfig.cpp" line="394"/>
        <source>Please download Subversion and set correct path in General settings.</source>
        <translation>Prosím nainstalujte si aplikaci Subversion a nastavte správnou cestu v obecném nastavení aplikace.</translation>
    </message>
    <message>
        <location filename="../ui/fktreeconfig.cpp" line="414"/>
        <source>Invalid location given!</source>
        <translation>Neplatná cesta!</translation>
    </message>
    <message>
        <location filename="../ui/fktreeconfig.cpp" line="415"/>
        <source>Cannot download SVN tree into this location: %1</source>
        <translation>Nelze stáhnout SVN strom do tohoto umístění: %1</translation>
    </message>
    <message>
        <location filename="../ui/fktreeconfig.cpp" line="181"/>
        <source>Path:</source>
        <translation>Cesta:</translation>
    </message>
    <message>
        <location filename="../ui/fktreeconfig.cpp" line="194"/>
        <source>Refresh tree</source>
        <translation>Obnovit seznam</translation>
    </message>
    <message>
        <location filename="../ui/fktreeconfig.cpp" line="195"/>
        <source>Update</source>
        <translation>Aktualizace repozitáře</translation>
    </message>
    <message>
        <location filename="../ui/fktreeconfig.cpp" line="196"/>
        <source>Delete local copy</source>
        <translation>Odstranit lokální kopii repozitáře</translation>
    </message>
    <message>
        <location filename="../ui/fktreeconfig.cpp" line="197"/>
        <location filename="../ui/fktreeconfig.cpp" line="274"/>
        <source>Repository settings</source>
        <translation>Konfigurace repozitáře</translation>
    </message>
    <message>
        <location filename="../ui/fktreeconfig.cpp" line="279"/>
        <source>&lt;h2&gt;Repository settings&lt;/h2&gt;</source>
        <translation>&lt;h2&gt;Konfigurace repozitáře&lt;/h2&gt;</translation>
    </message>
    <message>
        <location filename="../ui/fktreeconfig.cpp" line="288"/>
        <source>&lt;b&gt;Path:&lt;/b&gt;</source>
        <translation>&lt;b&gt;Adresa:&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../ui/fktreeconfig.cpp" line="289"/>
        <source>&lt;b&gt;Username:&lt;/b&gt;</source>
        <translation>&lt;b&gt;Uživatel:&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../ui/fktreeconfig.cpp" line="290"/>
        <source>&lt;b&gt;Password:&lt;/b&gt;</source>
        <translation>&lt;b&gt;Heslo:&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../ui/fktreeconfig.cpp" line="297"/>
        <source>No auth cache</source>
        <translation>Nekešovat autentizační údaje</translation>
    </message>
    <message>
        <location filename="../ui/fktreeconfig.cpp" line="300"/>
        <source>&amp;Accept</source>
        <translation>&amp;Uložit</translation>
    </message>
    <message>
        <location filename="../ui/fktreeconfig.cpp" line="301"/>
        <source>&amp;Cancel</source>
        <translation>&amp;Zrušit</translation>
    </message>
    <message>
        <location filename="../ui/fktreeconfig.cpp" line="425"/>
        <source>Repository update</source>
        <translation>Aktualizace repozitáře</translation>
    </message>
    <message>
        <location filename="../ui/fktreeconfig.cpp" line="491"/>
        <source>Build: libfitkit</source>
        <translation>Překlad: libfitkit</translation>
    </message>
    <message>
        <location filename="../ui/fktreeconfig.cpp" line="403"/>
        <source>GNU make not found!</source>
        <translation>Aplikace GNU Make nenalezena!</translation>
    </message>
    <message>
        <location filename="../ui/fktreeconfig.cpp" line="404"/>
        <source>Please download GNU MAKE (e.g. mingw32-make) and set correct path in General settings.</source>
        <translation>Prosím nainstalujte si aplikaci GNU make (např. mingw32-make) a nastavte správnou cestu v obecném nastavení aplikace.</translation>
    </message>
</context>
<context>
    <name>FkTreeWidget</name>
    <message>
        <location filename="../ui/fktreewidget.cpp" line="403"/>
        <source>FITKit applications</source>
        <translation>Aplikace pro FITKit</translation>
    </message>
    <message>
        <location filename="../ui/fktreewidget.cpp" line="411"/>
        <source>Refresh tree</source>
        <translation>Obnovit</translation>
    </message>
    <message>
        <location filename="../ui/fktreewidget.cpp" line="428"/>
        <source>Applications</source>
        <translation>Aplikace</translation>
    </message>
    <message>
        <location filename="../ui/fktreewidget.cpp" line="432"/>
        <source>&amp;Flash</source>
        <translation>&amp;Naprogramovat</translation>
    </message>
    <message>
        <source>&amp;Flash (forced)</source>
        <translation type="obsolete">N&amp;aprogramovat (vynuceně)</translation>
    </message>
    <message>
        <source>&amp;Build</source>
        <translation type="obsolete">&amp;Přeložit</translation>
    </message>
    <message>
        <source>&amp;Clean</source>
        <translation type="obsolete">&amp;Vyčistit</translation>
    </message>
    <message>
        <location filename="../ui/fktreewidget.cpp" line="442"/>
        <source>&amp;Readme</source>
        <translation>&amp;Readme</translation>
    </message>
    <message>
        <location filename="../ui/fktreewidget.cpp" line="443"/>
        <source>Run &amp;simulation (ModelSIM)</source>
        <translation>Spustit &amp;simulaci (ModelSIM)</translation>
    </message>
    <message>
        <location filename="../ui/fktreewidget.cpp" line="444"/>
        <source>Run &amp;simulation (ISIM)</source>
        <translation>Spustit s&amp;imulaci (ISIM)</translation>
    </message>
    <message>
        <location filename="../ui/fktreewidget.cpp" line="519"/>
        <source>&lt;h2&gt;Readme: %1&lt;/h2&gt;</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../ui/fktreewidget.cpp" line="521"/>
        <source>OK</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../ui/fktreewidget.cpp" line="538"/>
        <source>Flash</source>
        <translation>Nahrát</translation>
    </message>
    <message>
        <location filename="../ui/fktreewidget.cpp" line="701"/>
        <source>&lt;p&gt;%1&lt;/p&gt;&lt;b&gt;Author:&lt;/b&gt; %2&lt;br&gt;&lt;b&gt;Email:&lt;/b&gt; &lt;a href=&apos;mailto:%3&apos;&gt;%3&lt;/a&gt;&lt;br&gt;&lt;b&gt;Revision:&lt;/b&gt; &lt;i&gt;%4&lt;/i&gt;&lt;br&gt;</source>
        <translation>&lt;p&gt;%1&lt;/p&gt;&lt;b&gt;Autor:&lt;/b&gt; %2&lt;br&gt;&lt;b&gt;Email:&lt;/b&gt; &lt;a href=&apos;mailto:%3&apos;&gt;%3&lt;/a&gt;&lt;br&gt;&lt;b&gt;Revize:&lt;/b&gt; &lt;i&gt;%4&lt;/i&gt;&lt;br&gt;</translation>
    </message>
    <message>
        <location filename="../ui/fktreewidget.cpp" line="932"/>
        <source>No device selected.</source>
        <translation>Nebylo vybráno zařízení.</translation>
    </message>
    <message>
        <location filename="../ui/fktreewidget.cpp" line="933"/>
        <source>&lt;p&gt;Select device that should be programmed&lt;/p&gt;</source>
        <translation>&lt;p&gt;Vyberte zařízení pro programování&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../ui/fktreewidget.cpp" line="797"/>
        <source>Flash component not found!</source>
        <translation>Komponenta pro programování nenalezena!</translation>
    </message>
    <message>
        <location filename="../ui/fktreewidget.cpp" line="798"/>
        <source>Please install suitable flashing component like FKFlash plugin.</source>
        <translation>Prosím nainstalujte plugin pro programování (např. FKFlash).</translation>
    </message>
    <message>
        <location filename="../ui/fktreewidget.cpp" line="212"/>
        <location filename="../ui/fktreewidget.cpp" line="980"/>
        <source>GNU make not found!</source>
        <translation>Aplikace GNU make nenalezena!</translation>
    </message>
    <message>
        <location filename="../ui/fktreewidget.cpp" line="213"/>
        <location filename="../ui/fktreewidget.cpp" line="981"/>
        <source>Please download GNU MAKE (e.g. mingw32-make) and set correct path in General settings.</source>
        <translation>Prosím nainstalujte si aplikaci GNU make (např. mingw32-make) a nastavte správnou cestu v obecném nastavení aplikace.</translation>
    </message>
    <message>
        <location filename="../ui/fktreewidget.cpp" line="435"/>
        <source>&amp;Build (on foreground)</source>
        <translation>&amp;Přeložit (na popředí)</translation>
    </message>
    <message>
        <source>&amp;Run simulation</source>
        <translation type="obsolete">Spustit &amp;simulaci</translation>
    </message>
    <message>
        <source>&amp;Open project in ISE</source>
        <translation type="obsolete">&amp;Otevřít projekt v ISE</translation>
    </message>
    <message>
        <location filename="../ui/fktreewidget.cpp" line="438"/>
        <source>&amp;Clean (All files)</source>
        <translation>&amp;Vyčistit (vše)</translation>
    </message>
    <message>
        <location filename="../ui/fktreewidget.cpp" line="433"/>
        <source>Flash (forced)</source>
        <translation>Naprogramovat (vynuceně)</translation>
    </message>
    <message>
        <source>No known connections!</source>
        <translation type="obsolete">Nejsou nastaveny parametry pro vzdálený překlad!</translation>
    </message>
    <message>
        <location filename="../ui/fktreewidget.cpp" line="300"/>
        <source>Please see section &apos;Network&apos; in settings.</source>
        <translation>Parametry se nacházejí v nastavení síťe.</translation>
    </message>
    <message>
        <source>Select connection</source>
        <translation type="obsolete">Vyberte server pro vzdálený překlad</translation>
    </message>
    <message>
        <source>&lt;h2&gt;Select connection&lt;/h2&gt;</source>
        <translation type="obsolete">&lt;h2&gt;Vyberte server pro vzdálený překlad&lt;/h2&gt;</translation>
    </message>
    <message>
        <source>&amp;Accept</source>
        <translation type="obsolete">&amp;Ok</translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation type="obsolete">&amp;Zrušit</translation>
    </message>
    <message>
        <location filename="../ui/fktreewidget.cpp" line="434"/>
        <source>B&amp;uild</source>
        <translation>Přeložit aplikaci</translation>
    </message>
    <message>
        <location filename="../ui/fktreewidget.cpp" line="436"/>
        <source>Remote bu&amp;ild</source>
        <translation>Vzdálený &amp;překlad</translation>
    </message>
    <message>
        <location filename="../ui/fktreewidget.cpp" line="439"/>
        <source>Clean (MCU files)</source>
        <translation>Vyčistit (MCU soubory)</translation>
    </message>
    <message>
        <location filename="../ui/fktreewidget.cpp" line="440"/>
        <source>Clean (FPGA files)</source>
        <translation>Vyčistit (FPGA soubory)</translation>
    </message>
    <message>
        <source>Run &amp;simulation</source>
        <translation type="obsolete">Spustit &amp;simulaci</translation>
    </message>
    <message>
        <location filename="../ui/fktreewidget.cpp" line="445"/>
        <source>Open project in &amp;ISE</source>
        <translation>Otevřít projekt &amp;ISE</translation>
    </message>
    <message>
        <location filename="../ui/fktreewidget.cpp" line="1034"/>
        <source>Xilinx FUSE or XTCLSH not found!</source>
        <translation>Xilinx FUSE nebo XTCLSH nebylo nalezeno!</translation>
    </message>
    <message>
        <location filename="../ui/fktreewidget.cpp" line="1035"/>
        <source>Please download and install latest Xilinx ISE (at least 12.4). If the application is already installed, please check PATH variable.</source>
        <translation>Prosím stáhněte a nainstalujte poslední verzi Xilinx ISE (nejméně 12.40). Pokud je aplikace již nainstalována, zkontrolujte nastavení proměnné PATH.</translation>
    </message>
    <message>
        <location filename="../ui/fktreewidget.cpp" line="1053"/>
        <location filename="../ui/fktreewidget.cpp" line="1137"/>
        <source>XILINX ISE not found!</source>
        <translation>Aplikace XILINX ISE nenalezena!</translation>
    </message>
    <message>
        <location filename="../ui/fktreewidget.cpp" line="1054"/>
        <location filename="../ui/fktreewidget.cpp" line="1138"/>
        <source>Please download and install XILINX ISE. If the application is already installed, please check PATH variable.</source>
        <translation>Prosím stáhněte a nainstalujte XILINX ISE. Pokud máte již aplikaci nainstalovánu, zkontrolujte proměnnou PATH.</translation>
    </message>
    <message>
        <location filename="../ui/fktreewidget.cpp" line="1104"/>
        <source>MSP430-GCC not found!</source>
        <translation>Aplikace MSP430-GCC nenalezena!</translation>
    </message>
    <message>
        <location filename="../ui/fktreewidget.cpp" line="1105"/>
        <source>Please download and install MSP430 GCC. If the toolchain is already installed, please check PATH variable.</source>
        <translation>Prosím stáhněte a nainstalujte toolchain MSP430 GCC. Pokud máte již aplikaci nainstalovánu, zkontrolujte proměnnou PATH.</translation>
    </message>
    <message>
        <location filename="../ui/fktreewidget.cpp" line="1015"/>
        <source>ModelTech ModelSIM not found!</source>
        <translation>Aplikace ModelSIM nenalezena!</translation>
    </message>
    <message>
        <location filename="../ui/fktreewidget.cpp" line="298"/>
        <source>Build server not connected</source>
        <translation>Nepřipojeno k serveru pro překlad</translation>
    </message>
    <message>
        <location filename="../ui/fktreewidget.cpp" line="1016"/>
        <source>Please download and install ModelTech ModelSIM. If the application is already installed, please check PATH variable.</source>
        <translation>Prosím stáhněte a nainstalujte aplikaci ModelTech ModelSIM. Pokud máte již aplikaci nainstalovánu, zkontrolujte proměnnou PATH.</translation>
    </message>
    <message>
        <location filename="../ui/fktreewidget.cpp" line="1113"/>
        <source>MSP430-GCC error</source>
        <translation>MSP430-GCC chyba</translation>
    </message>
    <message>
        <location filename="../ui/fktreewidget.cpp" line="1114"/>
        <source>Please download and install latest MSP430 GCC. The installed version doesn&apos;t support required MCU models.</source>
        <translation>Prosím stáhněte a nainstalujte poslední verzi MSP430 GCC. Instalovaná verze nepodporuje potřebné modely MCU.</translation>
    </message>
    <message>
        <location filename="../ui/fktreewidget.cpp" line="235"/>
        <source>RM not found!</source>
        <translation>Utilita RM nenalezena!</translation>
    </message>
    <message>
        <location filename="../ui/fktreewidget.cpp" line="236"/>
        <source>Please download and install GNU RM utility. If the utility is already installed, please check PATH variable.</source>
        <translation>Prosím stáhněte a nainstalujte GNU utilitu RM. Pokud ji máte již nainstalovánu, zkontrolujte proměnnou PATH.</translation>
    </message>
    <message>
        <source>Build server not configured</source>
        <translation type="obsolete">Server pro překlad není nakonfigurován</translation>
    </message>
    <message>
        <location filename="../ui/fktreewidget.cpp" line="299"/>
        <source>Connection to build server is not configured.
</source>
        <translation>Připojení k serveru pro vzdálený překlad nebylo nakonfigurováno.
</translation>
    </message>
    <message>
        <location filename="../ui/fktreewidget.cpp" line="447"/>
        <source>Show &amp;documentation</source>
        <translation>Zobrazit &amp;dokumentaci</translation>
    </message>
    <message>
        <location filename="../ui/fktreewidget.cpp" line="493"/>
        <source>reST Browser component not found!</source>
        <translation>Komponenta reST Browser nenalezena!</translation>
    </message>
    <message>
        <location filename="../ui/fktreewidget.cpp" line="494"/>
        <source>Please install reST Browser plugin</source>
        <translation>Prosím nainstalujte si plugin reST Browser</translation>
    </message>
</context>
<context>
    <name>GeneralConfig</name>
    <message>
        <location filename="../ui/generalconfig.cpp" line="169"/>
        <source>&amp;General</source>
        <translation>&amp;Obecné nastavení</translation>
    </message>
    <message>
        <location filename="../ui/generalconfig.cpp" line="171"/>
        <source>Application settings</source>
        <translation>Nastavení aplikace</translation>
    </message>
    <message>
        <location filename="../ui/generalconfig.cpp" line="172"/>
        <source>System tray settings</source>
        <translation>Systémová lišta</translation>
    </message>
    <message>
        <location filename="../ui/generalconfig.cpp" line="173"/>
        <source>External paths</source>
        <translation>Cesty k aplikacím</translation>
    </message>
    <message>
        <location filename="../ui/generalconfig.cpp" line="176"/>
        <source>Ask before closing</source>
        <translation>Dotazovat se před ukončením</translation>
    </message>
    <message>
        <location filename="../ui/generalconfig.cpp" line="182"/>
        <source>Check if the required applications (ISE, GCC) are installed</source>
        <translation>Kontrolovat zda-li jsou nainstalované potřebné aplikace (ISE, GCC)</translation>
    </message>
    <message>
        <location filename="../ui/generalconfig.cpp" line="188"/>
        <source>Show system tray icon</source>
        <translation>Zobrazit ikonu v systémové liště</translation>
    </message>
    <message>
        <location filename="../ui/generalconfig.cpp" line="189"/>
        <source>Show system tray messages</source>
        <translation>Zobrazovat zprávy v systémové liště</translation>
    </message>
    <message>
        <location filename="../ui/generalconfig.cpp" line="193"/>
        <source>Make executable</source>
        <translation>Make</translation>
    </message>
    <message>
        <location filename="../ui/generalconfig.cpp" line="198"/>
        <source>SVN executable</source>
        <translation>Subversion</translation>
    </message>
    <message>
        <location filename="../ui/generalconfig.cpp" line="244"/>
        <source>Localiza&amp;tion</source>
        <translation>&amp;Lokalizace</translation>
    </message>
    <message>
        <location filename="../ui/generalconfig.cpp" line="249"/>
        <source>Please restart the application after localization change.</source>
        <translation>Pro provedení změn je třeba restartovat aplikaci.</translation>
    </message>
    <message>
        <location filename="../ui/generalconfig.cpp" line="179"/>
        <source>Ask for rebuild of out-dated project before programming</source>
        <translation>Nabídnout možnost přeložit modifikovaný projekt</translation>
    </message>
    <message>
        <location filename="../ui/generalconfig.cpp" line="203"/>
        <source>FCMake executable</source>
        <translation>FCMake</translation>
    </message>
    <message>
        <location filename="../ui/generalconfig.cpp" line="208"/>
        <source>FKFlash executable</source>
        <translation>FKFlash</translation>
    </message>
    <message>
        <location filename="../ui/generalconfig.cpp" line="185"/>
        <source>Show running tasks by default</source>
        <translation>Zobrazovat běžící úlohy jako výchozí</translation>
    </message>
</context>
<context>
    <name>JobScheduler</name>
    <message>
        <location filename="../jobscheduler.cpp" line="152"/>
        <source>Task &apos;%1&apos; started.</source>
        <translation>Úloha &apos;%1&apos; spuštěna.</translation>
    </message>
    <message>
        <location filename="../jobscheduler.cpp" line="155"/>
        <source>Task &apos;%1&apos; finished.</source>
        <translation>Úloha &apos;%1&apos; dokončena.</translation>
    </message>
    <message>
        <location filename="../jobscheduler.cpp" line="173"/>
        <source>No running tasks.</source>
        <translation>Žádne běžící úlohy.</translation>
    </message>
    <message>
        <location filename="../jobscheduler.cpp" line="180"/>
        <location filename="../jobscheduler.cpp" line="233"/>
        <source>Show running tasks.</source>
        <translation>Zobrazi běžící úlohy.</translation>
    </message>
    <message>
        <location filename="../jobscheduler.cpp" line="193"/>
        <source>%p % (%1 pending)</source>
        <translation>%p % (%1 čeká)</translation>
    </message>
    <message>
        <location filename="../jobscheduler.cpp" line="228"/>
        <source>Hide running tasks.</source>
        <translation>Skrýt běžící úlohy.</translation>
    </message>
    <message>
        <location filename="../jobscheduler.cpp" line="245"/>
        <source>&lt;b&gt;Currently %1 tasks pending :&lt;/b&gt;</source>
        <translation>&lt;b&gt;Běží %1 úloh :&lt;/b&gt;</translation>
    </message>
</context>
<context>
    <name>JobWidget</name>
    <message>
        <location filename="../ui/jobwidget.cpp" line="79"/>
        <source>Task progress.</source>
        <translation>Stav úlohy.</translation>
    </message>
    <message>
        <location filename="../ui/jobwidget.cpp" line="83"/>
        <source>Cancel task.</source>
        <translation>Zrušit úlohu.</translation>
    </message>
    <message>
        <location filename="../ui/jobwidget.cpp" line="55"/>
        <source>Task waiting.</source>
        <translation>Čeká.</translation>
    </message>
</context>
<context>
    <name>KeyItem</name>
    <message>
        <location filename="../ui/remoteconfig.cpp" line="450"/>
        <source>&lt;b&gt;%1 @ %2, port %3&lt;/b&gt;&lt;br&gt;</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../ui/remoteconfig.cpp" line="457"/>
        <source>&lt;small&gt;&lt;span&gt;no public key stored&lt;/span&gt;&lt;br&gt;&lt;/small&gt;</source>
        <translation>&lt;small&gt;&lt;span&gt;veřejný klíč není uložen&lt;/span&gt;&lt;br&gt;&lt;/small&gt;</translation>
    </message>
    <message>
        <location filename="../ui/remoteconfig.cpp" line="473"/>
        <source>&lt;small&gt;&lt;span&gt;fingerprint: %4&lt;/span&gt;&lt;br&gt;&lt;/small&gt;</source>
        <translation>&lt;small&gt;&lt;span&gt;otisk: %4&lt;/span&gt;&lt;br&gt;&lt;/small&gt;</translation>
    </message>
    <message>
        <location filename="../ui/remoteconfig.cpp" line="485"/>
        <source>Remove</source>
        <translation>Odstranit</translation>
    </message>
    <message>
        <location filename="../ui/remoteconfig.cpp" line="488"/>
        <source>Edit</source>
        <translation>Upravit</translation>
    </message>
</context>
<context>
    <name>LookConfig</name>
    <message>
        <location filename="../ui/lookconfig.cpp" line="176"/>
        <source>Fo&amp;nt</source>
        <translation>&amp;Písmo</translation>
    </message>
    <message>
        <location filename="../ui/lookconfig.cpp" line="185"/>
        <source>As bright and shiny as a newly minted coin.</source>
        <translation>Nablýskané a zářivé, jako čerstvě vyražená mince.</translation>
    </message>
    <message>
        <location filename="../ui/lookconfig.cpp" line="189"/>
        <source>Font family:</source>
        <translation>Písmo:</translation>
    </message>
    <message>
        <location filename="../ui/lookconfig.cpp" line="190"/>
        <source>Font size:</source>
        <translation>Velikost písma:</translation>
    </message>
    <message>
        <location filename="../ui/lookconfig.cpp" line="199"/>
        <source>Sample text</source>
        <translation>Ukázkový odstavec</translation>
    </message>
    <message>
        <location filename="../ui/lookconfig.cpp" line="216"/>
        <source>&amp;Highlighting</source>
        <translation>&amp;Zvýrazňovač</translation>
    </message>
    <message>
        <location filename="../ui/lookconfig.cpp" line="249"/>
        <source>Rule properties</source>
        <translation>Vlastnosti pravidla</translation>
    </message>
    <message>
        <location filename="../ui/lookconfig.cpp" line="254"/>
        <source>Context:</source>
        <translation>Kontext:</translation>
    </message>
    <message>
        <location filename="../ui/lookconfig.cpp" line="255"/>
        <source>Pattern:</source>
        <translation>Výraz:</translation>
    </message>
    <message>
        <location filename="../ui/lookconfig.cpp" line="263"/>
        <source>Format</source>
        <translation>Styl</translation>
    </message>
    <message>
        <location filename="../ui/lookconfig.cpp" line="267"/>
        <source>Bold</source>
        <translation>Tučně</translation>
    </message>
    <message>
        <location filename="../ui/lookconfig.cpp" line="268"/>
        <source>Italic</source>
        <translation>Kurzívou</translation>
    </message>
    <message>
        <location filename="../ui/lookconfig.cpp" line="269"/>
        <source>Underline</source>
        <translation>Podtrženo</translation>
    </message>
    <message>
        <location filename="../ui/lookconfig.cpp" line="270"/>
        <source>Strikeout</source>
        <translation>Přeškrtnuto</translation>
    </message>
    <message>
        <location filename="../ui/lookconfig.cpp" line="271"/>
        <source>Color</source>
        <translation>Barva</translation>
    </message>
    <message>
        <location filename="../ui/lookconfig.cpp" line="272"/>
        <source>Background</source>
        <translation>Pozadí</translation>
    </message>
    <message>
        <location filename="../ui/lookconfig.cpp" line="547"/>
        <source>Rule</source>
        <translation>Pravidlo</translation>
    </message>
    <message>
        <location filename="../ui/lookconfig.cpp" line="224"/>
        <source>Rul&amp;es</source>
        <translation>&amp;Pravidla</translation>
    </message>
    <message>
        <location filename="../ui/lookconfig.cpp" line="225"/>
        <source>Rules</source>
        <translation>Pravidla</translation>
    </message>
    <message>
        <location filename="../ui/lookconfig.cpp" line="226"/>
        <source>&amp;New</source>
        <translation>&amp;Nové pravidlo</translation>
    </message>
    <message>
        <location filename="../ui/lookconfig.cpp" line="227"/>
        <source>&amp;Remove</source>
        <translation>&amp;Odstranit pravidlo</translation>
    </message>
    <message>
        <location filename="../ui/lookconfig.cpp" line="228"/>
        <source>&amp;Defaults</source>
        <translation>&amp;Výchozí nastavení</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <source>Devices</source>
        <translation type="obsolete">Zařízení</translation>
    </message>
    <message>
        <location filename="../ui/mainwindow.cpp" line="179"/>
        <source>Enter password</source>
        <translation>Zadejte heslo</translation>
    </message>
    <message>
        <location filename="../ui/mainwindow.cpp" line="185"/>
        <source>Please enter password.</source>
        <translation>Prosím zadejte heslo.</translation>
    </message>
    <message>
        <location filename="../ui/mainwindow.cpp" line="194"/>
        <source>No public key was set for </source>
        <translation>Nebyl uložen veřejný klíč pro </translation>
    </message>
    <message>
        <location filename="../ui/mainwindow.cpp" line="205"/>
        <source>&amp;Accept</source>
        <translation>&amp;Ok</translation>
    </message>
    <message>
        <location filename="../ui/mainwindow.cpp" line="206"/>
        <source>&amp;Cancel</source>
        <translation>&amp;Zrušit</translation>
    </message>
    <message>
        <location filename="../ui/mainwindow.cpp" line="293"/>
        <source>E&amp;xit</source>
        <translation>U&amp;končit</translation>
    </message>
    <message>
        <location filename="../ui/mainwindow.cpp" line="294"/>
        <source>&amp;Close current</source>
        <translation>&amp;Zavřít současný tab</translation>
    </message>
    <message>
        <location filename="../ui/mainwindow.cpp" line="298"/>
        <source>Add &amp;local connection</source>
        <translation>Přidat &amp;místní</translation>
    </message>
    <message>
        <location filename="../ui/mainwindow.cpp" line="299"/>
        <source>Add &amp;remote connection</source>
        <translation>Přidat vz&amp;dálený</translation>
    </message>
    <message>
        <location filename="../ui/mainwindow.cpp" line="302"/>
        <location filename="../ui/mainwindow.cpp" line="341"/>
        <source>&amp;Settings</source>
        <translation>&amp;Nastavení</translation>
    </message>
    <message>
        <location filename="../ui/mainwindow.cpp" line="305"/>
        <location filename="../ui/mainwindow.cpp" line="346"/>
        <source>&amp;Help</source>
        <translation>Ná&amp;pověda</translation>
    </message>
    <message>
        <location filename="../ui/mainwindow.cpp" line="306"/>
        <source>&amp;About</source>
        <translation>&amp;O Aplikaci</translation>
    </message>
    <message>
        <location filename="../ui/mainwindow.cpp" line="307"/>
        <source>About &amp;Qt</source>
        <translation>O &amp;Qt</translation>
    </message>
    <message>
        <location filename="../ui/mainwindow.cpp" line="324"/>
        <source>&amp;Connection</source>
        <translation>&amp;FITKit</translation>
    </message>
    <message>
        <location filename="../ui/mainwindow.cpp" line="334"/>
        <source>&amp;View</source>
        <translation>Z&amp;obrazit</translation>
    </message>
    <message>
        <location filename="../ui/mainwindow.cpp" line="335"/>
        <source>&amp;Panels</source>
        <translation>&amp;Panely</translation>
    </message>
    <message>
        <location filename="../ui/mainwindow.cpp" line="360"/>
        <source>Toolbar</source>
        <translation>Lišta</translation>
    </message>
    <message>
        <location filename="../ui/mainwindow.cpp" line="488"/>
        <location filename="../ui/mainwindow.cpp" line="584"/>
        <source>Settings</source>
        <translation>Nastavení</translation>
    </message>
    <message>
        <location filename="../ui/mainwindow.cpp" line="507"/>
        <source>Add remote device</source>
        <translation>Přidat vzdálené zařízení</translation>
    </message>
    <message>
        <location filename="../ui/mainwindow.cpp" line="513"/>
        <source>Host address:</source>
        <translation>Adresa:</translation>
    </message>
    <message>
        <location filename="../ui/mainwindow.cpp" line="552"/>
        <source>Connecting to </source>
        <translation>Připojuji se na </translation>
    </message>
    <message>
        <location filename="../ui/mainwindow.cpp" line="575"/>
        <source>Failed to connect to remote host.</source>
        <translation>Nepodařilo se připojit k vzdálenému zařízení.</translation>
    </message>
    <message>
        <location filename="../ui/mainwindow.cpp" line="250"/>
        <source>Applications</source>
        <translation>Aplikace</translation>
    </message>
</context>
<context>
    <name>PluginMgr</name>
    <message>
        <location filename="../pluginmgr.cpp" line="88"/>
        <location filename="../pluginmgr.cpp" line="110"/>
        <source>Plugin error</source>
        <translation>Chyba při nahrávání pluginu</translation>
    </message>
    <message>
        <location filename="../pluginmgr.cpp" line="89"/>
        <source>Failed to find plugin &quot;%1&quot;.&lt;br&gt;Reason: missing plugin.xml file</source>
        <translation>Nepodařilo se nalézt plugin &quot;%1&quot;&lt;br&gt;Příčina: chybějící soubor plugin.xml</translation>
    </message>
    <message>
        <location filename="../pluginmgr.cpp" line="111"/>
        <source>Failed to load plugin &quot;%1&quot;.&lt;br&gt;Reason: %2</source>
        <translation>Nepodařilo se načíst plugin &quot;%1&quot;&lt;br&gt;Příčina: %2</translation>
    </message>
</context>
<context>
    <name>PluginWidget</name>
    <message>
        <location filename="../ui/pluginconfig.cpp" line="198"/>
        <source>&lt;b&gt;%1&lt;/b&gt;&lt;br&gt;%2&lt;br&gt;&lt;small&gt;&lt;span&gt;%3, &lt;a href=&apos;mailto:%4&apos;&gt;%4&lt;/a&gt;&lt;/span&gt;&lt;br&gt;Version: &lt;b&gt;%5&lt;/b&gt; License: &lt;b&gt;%6&lt;/b&gt;&lt;br&gt;&lt;i&gt;(%7)&lt;/i&gt;&lt;/small&gt;</source>
        <translation>&lt;b&gt;%1&lt;/b&gt;&lt;br&gt;%2&lt;br&gt;&lt;small&gt;&lt;span&gt;%3, &lt;a href=&apos;mailto:%4&apos;&gt;%4&lt;/a&gt;&lt;/span&gt;&lt;br&gt;Verze: &lt;b&gt;%5&lt;/b&gt; Licence: &lt;b&gt;%6&lt;/b&gt;&lt;br&gt;&lt;i&gt;(%7)&lt;/i&gt;&lt;/small&gt;</translation>
    </message>
    <message>
        <location filename="../ui/pluginconfig.cpp" line="211"/>
        <source>binary plugin</source>
        <translation>binární modul</translation>
    </message>
    <message>
        <location filename="../ui/pluginconfig.cpp" line="211"/>
        <source>python script</source>
        <translation>python skript</translation>
    </message>
    <message>
        <location filename="../ui/pluginconfig.cpp" line="216"/>
        <source>Unknown</source>
        <translation>Neznámé</translation>
    </message>
    <message>
        <location filename="../ui/pluginconfig.cpp" line="217"/>
        <source>Configure</source>
        <translation>Nastavení</translation>
    </message>
    <message>
        <location filename="../ui/pluginconfig.cpp" line="252"/>
        <source>Unload</source>
        <translation>Odpojit</translation>
    </message>
    <message>
        <location filename="../ui/pluginconfig.cpp" line="260"/>
        <source>Load</source>
        <translation>Zapojit</translation>
    </message>
</context>
<context>
    <name>ProcessJob</name>
    <message>
        <location filename="../ui/processjob.cpp" line="121"/>
        <location filename="../ui/processjob.cpp" line="250"/>
        <source>Show task details.</source>
        <translation>Zobrazit běžící úlohy.</translation>
    </message>
    <message>
        <location filename="../ui/processjob.cpp" line="275"/>
        <source>Hide task details.</source>
        <translation>Skrýt bežící úlohy.</translation>
    </message>
    <message>
        <location filename="../ui/processjob.cpp" line="336"/>
        <source>Command not found: %1</source>
        <translation>Příkaz nenalezen: %1</translation>
    </message>
</context>
<context>
    <name>QDeviceMgr</name>
    <message>
        <location filename="../qdevicemgr.cpp" line="178"/>
        <location filename="../qdevicemgr.cpp" line="192"/>
        <source>DeviceID:	%1</source>
        <translation>DeviceID:	%1</translation>
    </message>
    <message>
        <location filename="../qdevicemgr.cpp" line="179"/>
        <location filename="../qdevicemgr.cpp" line="193"/>
        <source>Product:	</source>
        <translation>Produkt:</translation>
    </message>
    <message>
        <location filename="../qdevicemgr.cpp" line="180"/>
        <location filename="../qdevicemgr.cpp" line="194"/>
        <source>Serial:	</source>
        <translation>Sér. číslo:</translation>
    </message>
    <message>
        <location filename="../qdevicemgr.cpp" line="182"/>
        <source>Device connected.</source>
        <translation>Zařízení připojeno.</translation>
    </message>
    <message>
        <location filename="../qdevicemgr.cpp" line="196"/>
        <source>Device disconnected.</source>
        <translation>Zařízení odpojeno.</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../pluginloader.cpp" line="78"/>
        <source>unable to parse plugin.xml</source>
        <translation>Chyba při parsování souboru plugin.xml</translation>
    </message>
    <message>
        <location filename="../pluginloader.cpp" line="87"/>
        <source>bad plugin.xml root node</source>
        <translation>Soubor plugin.xml má chybný root</translation>
    </message>
    <message>
        <location filename="../pluginloader.cpp" line="105"/>
        <source>unrecognized plugin type</source>
        <translation>Neznámý typ pluginu</translation>
    </message>
    <message>
        <location filename="../pluginloader.cpp" line="127"/>
        <source>unknown error during loading plugin</source>
        <translation>Neznámá chyba během načítání pluginu</translation>
    </message>
</context>
<context>
    <name>RBuildJob</name>
    <message>
        <source>Show task details.</source>
        <translation type="obsolete">Zobrazit běžící úlohy.</translation>
    </message>
    <message>
        <source>Hide task details.</source>
        <translation type="obsolete">Skrýt bežící úlohy.</translation>
    </message>
    <message>
        <source>Enter password</source>
        <translation type="obsolete">Zadejte heslo</translation>
    </message>
    <message>
        <source>&lt;h2&gt;Please enter password.&lt;/h2&gt;</source>
        <translation type="obsolete">&lt;h2&gt;Zadejte heslo.&lt;/h2&gt;</translation>
    </message>
    <message>
        <source>No public key was set for </source>
        <translation type="obsolete">Nebyl uložen veřejný klíč pro </translation>
    </message>
    <message>
        <source>&amp;Accept</source>
        <translation type="obsolete">&amp;Ok</translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation type="obsolete">&amp;Zrušit</translation>
    </message>
</context>
<context>
    <name>RebuildDialog</name>
    <message>
        <location filename="../ui/rebuilddialog.ui" line="16"/>
        <source>Quit?</source>
        <translation>Ukončit aplikaci?</translation>
    </message>
    <message>
        <location filename="../ui/rebuilddialog.ui" line="67"/>
        <source>Do not ask again</source>
        <translation>Znovu se nedotazovat</translation>
    </message>
    <message>
        <location filename="../ui/rebuilddialog.ui" line="80"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:7.8pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:8pt;&quot;&gt;&lt;span style=&quot; font-size:10pt; font-weight:600;&quot;&gt;The sources have been modified&lt;/span&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt; &lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:10pt;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:10pt;&quot;&gt;Do you want to rebuild the project?&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;p, li { white-space: pre-wrap; }&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:7.8pt; font-weight:400; font-style:normal;&quot;&gt;&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:8pt;&quot;&gt;&lt;span style=&quot; font-size:10pt; font-weight:600;&quot;&gt;Zdrojové soubory byly modifikovány&lt;/span&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt; &lt;/span&gt;&lt;/p&gt;&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:10pt;&quot;&gt;&lt;/p&gt;&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:10pt;&quot;&gt;Přejete si znovu přeložit projekt?&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
</context>
<context>
    <name>RemoteConfig</name>
    <message>
        <source>Add new connection</source>
        <translation type="obsolete">Přidat nové spojení</translation>
    </message>
    <message>
        <source>&lt;h2&gt;Add new connection&lt;/h2&gt;</source>
        <translation type="obsolete">&lt;h2&gt;Přidat nové spojení&lt;/h2&gt;</translation>
    </message>
    <message>
        <source>&lt;b&gt;Username:&lt;/b&gt;</source>
        <translation type="obsolete">&lt;b&gt;Uživatel:&lt;/b&gt;</translation>
    </message>
    <message>
        <source>&lt;b&gt;Password:&lt;/b&gt;</source>
        <translation type="obsolete">&lt;b&gt;Heslo:&lt;/b&gt;</translation>
    </message>
    <message>
        <source>&lt;b&gt;Store public key:&lt;/b&gt;</source>
        <translation type="obsolete">&lt;b&gt;Uložit veřejný klíč:&lt;/b&gt;</translation>
    </message>
    <message>
        <source>&amp;Accept</source>
        <translation type="obsolete">&amp;Ok</translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation type="obsolete">&amp;Zrušit</translation>
    </message>
    <message>
        <source>Optional parameters:</source>
        <translation type="obsolete">Další parametry:</translation>
    </message>
    <message>
        <source>Error: Server hostname is empty.</source>
        <translation type="obsolete">Chyba: Adresa serveru je prázdná.</translation>
    </message>
    <message>
        <source>Authenticating with remote server...</source>
        <translation type="obsolete">Probíhá autentizace k vzdálenému serveru...</translation>
    </message>
    <message>
        <source>Key created.</source>
        <translation type="obsolete">Veřejný klíč uložen.</translation>
    </message>
    <message>
        <source>Error: Authenticating with remote host failed.</source>
        <translation type="obsolete">Chyba: Nepodařilo se přihlásit k vzdálenému serveru.</translation>
    </message>
    <message>
        <source>&amp;Build server</source>
        <translation type="obsolete">&amp;Vzdálený překlad</translation>
    </message>
    <message>
        <source>Authenticated servers:</source>
        <translation type="obsolete">Autentizované servery:</translation>
    </message>
    <message>
        <source>Add</source>
        <translation type="obsolete">Přidat</translation>
    </message>
    <message>
        <location filename="../ui/remoteconfig.cpp" line="252"/>
        <source>Default build:</source>
        <translation>Výchozí nástroj:</translation>
    </message>
    <message>
        <location filename="../ui/remoteconfig.cpp" line="254"/>
        <source>Local tools</source>
        <translation>Lokální překlad</translation>
    </message>
    <message>
        <location filename="../ui/remoteconfig.cpp" line="218"/>
        <location filename="../ui/remoteconfig.cpp" line="255"/>
        <source>Build server</source>
        <translation>Vzdálený překlad</translation>
    </message>
    <message>
        <location filename="../ui/remoteconfig.cpp" line="217"/>
        <source>Remote devices</source>
        <translation>Vzdálená zařízení</translation>
    </message>
    <message>
        <location filename="../ui/remoteconfig.cpp" line="225"/>
        <source>Discover devices in local network</source>
        <translation>Hledat zařízení v místní síti</translation>
    </message>
    <message>
        <location filename="../ui/remoteconfig.cpp" line="230"/>
        <source>Share devices automatically</source>
        <translation>Automaticky sdílet připojená zařízení</translation>
    </message>
    <message>
        <location filename="../ui/remoteconfig.cpp" line="239"/>
        <source>No connection configured.</source>
        <translation>Připojení k serveru pro vzdálený překlad není nakonfigurováno.</translation>
    </message>
    <message>
        <location filename="../ui/remoteconfig.cpp" line="241"/>
        <source>Connect to build server</source>
        <translation>Nové připojení</translation>
    </message>
    <message>
        <location filename="../ui/remoteconfig.cpp" line="263"/>
        <source>Default ports: </source>
        <translation>Výchozí porty:</translation>
    </message>
    <message>
        <location filename="../ui/remoteconfig.cpp" line="266"/>
        <source>License tunelling:</source>
        <translation>Tunelování licencí:</translation>
    </message>
    <message>
        <location filename="../ui/remoteconfig.cpp" line="269"/>
        <source>Ports:</source>
        <translation>Porty:</translation>
    </message>
    <message>
        <source>&amp;Remote devices</source>
        <translation type="obsolete">Vz&amp;dálená zařízení</translation>
    </message>
    <message>
        <source>Known servers:</source>
        <translation type="obsolete">Autentizované servery:</translation>
    </message>
</context>
<context>
    <name>RemoteDialog</name>
    <message>
        <location filename="../ui/remoteconfig.cpp" line="296"/>
        <source>Error: Server hostname is empty.</source>
        <translation>Chyba: Adresa serveru je prázdná.</translation>
    </message>
    <message>
        <location filename="../ui/remoteconfig.cpp" line="310"/>
        <source>Authenticating with remote server...</source>
        <translation>Probíhá autentizace k vzdálenému serveru...</translation>
    </message>
    <message>
        <location filename="../ui/remoteconfig.cpp" line="313"/>
        <source>Key created.</source>
        <translation>Veřejný klíč uložen.</translation>
    </message>
    <message>
        <location filename="../ui/remoteconfig.cpp" line="319"/>
        <source>Error: Authenticating with remote host failed.</source>
        <translation>Chyba: Nepodařilo se přihlásit k vzdálenému serveru.</translation>
    </message>
    <message>
        <location filename="../ui/remoteconfig.cpp" line="329"/>
        <source>Authenticate with build server</source>
        <translation>Přihlásit se k serveru pro vzdálený překlad</translation>
    </message>
    <message>
        <location filename="../ui/remoteconfig.cpp" line="335"/>
        <source>Add new connection</source>
        <translation>Přidat nové spojení</translation>
    </message>
    <message>
        <location filename="../ui/remoteconfig.cpp" line="340"/>
        <source>&lt;b&gt;Server:&lt;/b&gt;</source>
        <translation>&lt;b&gt;Server:&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../ui/remoteconfig.cpp" line="341"/>
        <source>Build server %1 is reachable only within VUT network.
In case of connection troubles, please use merlin.fit.vutbr.cz.</source>
        <translation>Překladový server %1 je dostupný pouze v rámci VUT sítě.
V případě problému s dostupností prosím použijte server merlin.fit.vutbr.cz.</translation>
    </message>
    <message>
        <source>Build server %1 is reachable only within VUT network. In case of troubles, please use merlin.fit.vutbr.cz.</source>
        <translation type="obsolete">Překladový server %1 je dostupný pouze v rámci VUT sítě.
V případě problému s dostupností prosím použijte server merlin.fit.vutbr.cz.</translation>
    </message>
    <message>
        <location filename="../ui/remoteconfig.cpp" line="343"/>
        <source>&lt;b&gt;Username:&lt;/b&gt;</source>
        <translation>&lt;b&gt;Uživatel:&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../ui/remoteconfig.cpp" line="344"/>
        <source>&lt;b&gt;Password:&lt;/b&gt;</source>
        <translation>&lt;b&gt;Heslo:&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../ui/remoteconfig.cpp" line="345"/>
        <source>&lt;b&gt;Port:&lt;/b&gt;</source>
        <translation>&lt;b&gt;Port:&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../ui/remoteconfig.cpp" line="346"/>
        <source>&lt;b&gt;Store authentication key:&lt;/b&gt;</source>
        <translation>&lt;b&gt;Uložit autentizační klíč:&lt;/b&gt;</translation>
    </message>
    <message>
        <source>&lt;b&gt;Store public key:&lt;/b&gt;</source>
        <translation type="obsolete">&lt;b&gt;Uložit veřejný klíč:&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../ui/remoteconfig.cpp" line="357"/>
        <source>Password will not be stored.</source>
        <translation>Heslo nebude nikde uloženo.</translation>
    </message>
    <message>
        <location filename="../ui/remoteconfig.cpp" line="361"/>
        <source>&amp;Accept</source>
        <translation>&amp;Ok</translation>
    </message>
    <message>
        <location filename="../ui/remoteconfig.cpp" line="363"/>
        <source>&amp;Cancel</source>
        <translation>&amp;Zrušit</translation>
    </message>
    <message>
        <location filename="../ui/remoteconfig.cpp" line="375"/>
        <source>Authentication key will be stored in your configuration.&lt;br/&gt;Do not store keys if your computer may  be compromised.</source>
        <translation>Autentizační klíč bude uložen v konfiguraci programu.&lt;br/&gt;Nepoužívejte funkci ukládání klíčů pokud váš počítač&lt;br/&gt;není dostatečně chráněn a může být snadno napaden.</translation>
    </message>
    <message>
        <location filename="../ui/remoteconfig.cpp" line="401"/>
        <source>Optional parameters:</source>
        <translation>Další parametry:</translation>
    </message>
</context>
<context>
    <name>Settings</name>
    <message>
        <location filename="../ui/settings.cpp" line="79"/>
        <source>Accept</source>
        <translation>Uložit</translation>
    </message>
    <message>
        <location filename="../ui/settings.cpp" line="80"/>
        <source>Close</source>
        <translation>Zavřít</translation>
    </message>
    <message>
        <location filename="../ui/settings.cpp" line="176"/>
        <source>General</source>
        <translation>Obecné</translation>
    </message>
    <message>
        <location filename="../ui/settings.cpp" line="177"/>
        <source>Fonts &amp; Colors</source>
        <translation>Vzhled</translation>
    </message>
    <message>
        <location filename="../ui/settings.cpp" line="178"/>
        <source>Device</source>
        <translation>Zařízení</translation>
    </message>
    <message>
        <location filename="../ui/settings.cpp" line="179"/>
        <source>Network</source>
        <translation>Síť</translation>
    </message>
    <message>
        <location filename="../ui/settings.cpp" line="180"/>
        <source>Plugins</source>
        <translation>Pluginy</translation>
    </message>
    <message>
        <location filename="../ui/settings.cpp" line="181"/>
        <source>Applications</source>
        <translation>Projekty</translation>
    </message>
</context>
<context>
    <name>TrayIcon</name>
    <message>
        <location filename="../trayicon.cpp" line="44"/>
        <source>QDevKit</source>
        <translation>QDevKit</translation>
    </message>
</context>
<context>
    <name>TunnelService</name>
    <message>
        <location filename="../tunnel.cpp" line="184"/>
        <source>Connecting...</source>
        <translation>Připojuji se...</translation>
    </message>
    <message>
        <location filename="../tunnel.cpp" line="203"/>
        <source>Please enter password for</source>
        <translation>Prosím zadejte heslo pro</translation>
    </message>
    <message>
        <location filename="../tunnel.cpp" line="307"/>
        <source>Not connected to build server</source>
        <translation>Nepřipojeno k serveru pro překlad</translation>
    </message>
    <message>
        <location filename="../tunnel.cpp" line="312"/>
        <source>Build server tunnel</source>
        <translation>Tunel k serveru pro překlad</translation>
    </message>
    <message>
        <location filename="../tunnel.cpp" line="319"/>
        <source>License tunnels</source>
        <translation>Tunely k licenčním serverům</translation>
    </message>
    <message>
        <location filename="../tunnel.cpp" line="328"/>
        <source>Connections</source>
        <translation>Připojení</translation>
    </message>
    <message>
        <location filename="../tunnel.cpp" line="331"/>
        <source>Connected to build server</source>
        <translation>Připojeno k serveru pro překlad</translation>
    </message>
    <message>
        <location filename="../tunnel.cpp" line="364"/>
        <source>Hostname &quot;semik&quot; doesn&apos;t point to 127.0.0.1</source>
        <translation>Hostname &quot;semik&quot; není směrováno na 127.0.0.1</translation>
    </message>
    <message>
        <location filename="../tunnel.cpp" line="366"/>
        <source>Please set &apos;semik&apos; to 127.0.0.1 in your hosts file.</source>
        <translation>Prosím nastavte doménové jméno &apos;semik&apos; na 127.0.0.1 v souboru hosts.</translation>
    </message>
    <message>
        <source>Not connected to build server.</source>
        <translation type="obsolete">Nepřipojeno k serveru pro překlad.</translation>
    </message>
    <message>
        <source>&quot;semik&quot; doesn&apos;t point to 127.0.0.1</source>
        <translation type="obsolete">&quot;semik&quot; neodkazuje na 127.0.0.1</translation>
    </message>
    <message>
        <source>License server needs to resolve &apos;semik&apos; as a valid license server address.
Please set &apos;semik&apos; to 127.0.0.1 in your /etc/hosts or lmhosts.</source>
        <translation type="obsolete">Licenční server potřebuje přeložit doménové jméno &apos;semik&apos; na platnou adresu licenčního serveru.
Z toho důvodu prosím nastavte v /etc/hosts nebo lmhosts adresu jména &apos;semik&apos; na &apos;127.0.0.1&apos;.</translation>
    </message>
</context>
</TS>

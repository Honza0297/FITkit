This example shows how to add user defined Python classes
to the embedded Python mainModule.

It also shows how to create objects in Python,
hold onto reference counted smart pointers to them from 
a Qt application, and invoke methods on them via
the PythonQtObjectPtr interface.

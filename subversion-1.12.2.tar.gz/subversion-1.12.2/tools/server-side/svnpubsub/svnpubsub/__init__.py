# Turn svnpubsub/ into a package.
